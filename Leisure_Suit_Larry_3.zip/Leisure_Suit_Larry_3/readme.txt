




                      Welcome To Nontoonyt Island and
                           Leisure Suit Larry 3:
            Passionate Patti in Pursuit of the Pulsating Pectorals

                                  by Al Lowe


Thank you for purchasing this game.  I hope you enjoy playing it 
as much as all of us enjoyed creating it!






